To run A2.ipynb:
1. Run the import section at the beginning of the code
2. Each question has a dedicated function called run_Q'x' within the code block
3. To run a question using a particular dataset, specify the dataset in the already given run_Q'x'() command at the end of each question section
4. All the relevant figures and results will show up automatically, so the whole process involves specifying what dataset you'd like to use within each of the run_Q'x' functions